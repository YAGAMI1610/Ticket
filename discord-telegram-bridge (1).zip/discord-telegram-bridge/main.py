"""
main.py — Bot-only entry point.

Run with:
    python main.py

This mode is suitable for VPS deployments where you only need
the Discord → Telegram bridge without an HTTP server.
"""

from __future__ import annotations

import asyncio
import sys

from bot.discord_bot import create_bot
from core.config import get_settings
from core.logger import get_logger, setup_logging


async def main() -> None:
    settings = get_settings()
    setup_logging(settings.log_level)

    log = get_logger(__name__)
    log.info("Starting Discord → Telegram bridge (bot-only mode)")
    log.info("Ticket keywords: %s", settings.ticket_keyword_list)

    if settings.allowed_guild_id_list:
        log.info("Monitoring guilds: %s", settings.allowed_guild_id_list)
    else:
        log.info("Monitoring all guilds")

    bot = create_bot(settings)

    try:
        await bot.start(settings.discord_token)
    except KeyboardInterrupt:
        log.info("Received interrupt — shutting down…")
    finally:
        if not bot.is_closed():
            await bot.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as exc:
        print(f"Fatal error: {exc}", file=sys.stderr)
        sys.exit(1)
