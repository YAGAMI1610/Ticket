"""
api/app.py — FastAPI application factory.

Manages shared state (Telegram client, Discord bot) via lifespan context.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes import router
from bot.discord_bot import create_bot
from core.config import Settings, get_settings
from core.logger import get_logger
from core.telegram import TelegramClient

log = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    FastAPI lifespan: initialise shared resources before serving,
    clean them up on shutdown.
    """
    settings: Settings = get_settings()

    # ── Startup ───────────────────────────────────────────────────────────────
    log.info("Starting up — initialising Telegram client…")
    telegram = TelegramClient(
        token=settings.telegram_token,
        default_chat_id=settings.telegram_chat_id,
    )
    await telegram.__aenter__()
    app.state.telegram = telegram

    # Verify Telegram credentials
    try:
        bot_info = await telegram.test_connection()
        log.info("Telegram bot verified: @%s", bot_info.get("username", "unknown"))
    except Exception as exc:
        log.error("Telegram connection test failed at startup: %s", exc)

    # Start Discord bot in a background task
    log.info("Starting Discord bot in background…")
    bot = create_bot(settings)
    app.state.bot = bot

    # Share the Telegram client with the bot
    bot._telegram = telegram
    await bot._telegram.__aenter__()  # already open, but sets internal flag

    discord_task = asyncio.create_task(
        bot.start(settings.discord_token),
        name="discord-bot",
    )

    log.info("Application ready")
    yield  # ← server is live

    # ── Shutdown ──────────────────────────────────────────────────────────────
    log.info("Shutting down…")
    discord_task.cancel()

    if not bot.is_closed():
        await bot.close()

    await telegram.__aexit__(None, None, None)
    log.info("Shutdown complete")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title="Discord → Telegram Bridge",
        description="Monitors Discord for ticket channels and forwards alerts to Telegram.",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # CORS (restrict in production to your actual domains)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )

    app.include_router(router)

    return app
