"""api — FastAPI application for webhook-based scaling."""
