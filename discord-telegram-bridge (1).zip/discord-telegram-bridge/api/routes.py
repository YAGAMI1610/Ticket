"""
api/routes.py — FastAPI route definitions.

Provides:
  GET  /health      — liveness + readiness probe
  POST /webhook     — manual ticket notification trigger (for testing)
  GET  /status      — bot connection status
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from core.formatter import TicketEvent, format_ticket_message
from core.logger import get_logger
from core.telegram import TelegramClient, TelegramError

log = get_logger(__name__)
router = APIRouter()

_START_TIME = time.time()


# ── Schemas ───────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    uptime_seconds: float
    discord_connected: bool
    version: str = "1.0.0"


class WebhookPayload(BaseModel):
    """Manual webhook payload for testing or external integrations."""
    channel_name: str = Field(..., example="ticket-1234")
    channel_id: int = Field(..., example=1234567890)
    guild_name: str = Field(..., example="My Server")
    guild_id: int = Field(..., example=9876543210)
    creator_id: Optional[int] = Field(None, example=111222333)
    creator_name: Optional[str] = Field(None, example="user#1234")
    category_name: Optional[str] = Field(None, example="Support")


class WebhookResponse(BaseModel):
    success: bool
    message: str


# ── Dependencies ──────────────────────────────────────────────────────────────

def get_telegram(request: Request) -> TelegramClient:
    """Inject Telegram client from app state."""
    client: Optional[TelegramClient] = getattr(request.app.state, "telegram", None)
    if client is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Telegram client not initialised",
        )
    return client


def get_bot(request: Request) -> Any:
    """Inject Discord bot from app state."""
    return getattr(request.app.state, "bot", None)


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/health", response_model=HealthResponse, tags=["monitoring"])
async def health_check(bot: Any = Depends(get_bot)) -> HealthResponse:
    """Liveness + readiness probe. Used by Render, Kubernetes, etc."""
    discord_connected = bool(bot and not bot.is_closed())
    return HealthResponse(
        status="ok" if discord_connected else "degraded",
        uptime_seconds=round(time.time() - _START_TIME, 2),
        discord_connected=discord_connected,
    )


@router.get("/status", tags=["monitoring"])
async def status_check(bot: Any = Depends(get_bot)) -> Dict[str, Any]:
    """Detailed status including connected guilds."""
    if not bot or bot.is_closed():
        return {"connected": False, "guilds": []}

    return {
        "connected": True,
        "bot_user": str(bot.user) if bot.user else None,
        "guilds": [
            {"id": g.id, "name": g.name, "member_count": g.member_count}
            for g in bot.guilds
        ],
    }


@router.post("/webhook", response_model=WebhookResponse, tags=["webhook"])
async def manual_webhook(
    payload: WebhookPayload,
    telegram: TelegramClient = Depends(get_telegram),
) -> WebhookResponse:
    """
    Manually trigger a Telegram notification.

    Useful for:
    - Testing your Telegram setup
    - Integrating external ticket systems
    - Replaying missed events
    """
    log.info("Manual webhook received for channel #%s", payload.channel_name)

    event = TicketEvent(
        channel_name=payload.channel_name,
        channel_id=payload.channel_id,
        guild_name=payload.guild_name,
        guild_id=payload.guild_id,
        creator_id=payload.creator_id,
        creator_name=payload.creator_name,
        category_name=payload.category_name,
    )

    message = format_ticket_message(event)

    try:
        await telegram.send_message(message)
        log.info("Manual webhook notification sent for #%s", payload.channel_name)
        return WebhookResponse(success=True, message="Notification sent to Telegram")
    except TelegramError as exc:
        log.error("Telegram error during webhook: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Telegram API error: {exc.description}",
        )
