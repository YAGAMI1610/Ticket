"""core — shared utilities for Discord-Telegram bridge."""
