"""
core/formatter.py — Formats Discord ticket data into Telegram messages.
Matches the alert style with server name, channel, creator info and profile link.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class TicketEvent:
    """Structured representation of a detected ticket channel creation."""

    channel_name: str
    channel_id: int
    guild_name: str
    guild_id: int
    creator_id: Optional[int] = None
    creator_name: Optional[str] = None
    category_name: Optional[str] = None
    detected_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def channel_url(self) -> str:
        return f"https://discord.com/channels/{self.guild_id}/{self.channel_id}"

    @property
    def profile_url(self) -> Optional[str]:
        if self.creator_id:
            return f"https://discord.com/users/{self.creator_id}"
        return None


def format_ticket_message(event: TicketEvent) -> str:
    """Format a TicketEvent into a Telegram HTML message."""

    profile = (
        f'<a href="{event.profile_url}">{event.profile_url}</a>'
        if event.profile_url
        else "N/A"
    )

    username = f"<b>{_esc(event.creator_name)}</b>" if event.creator_name else "Unknown"
    creator_id = str(event.creator_id) if event.creator_id else "Unknown"

    lines = [
        f"🎟 <b>New Ticket Detected in {_esc(event.guild_name)}</b>",
        f"Channel: <b>{_esc(event.channel_name)}</b>",
        f"ID: {event.channel_id}",
        f"Creator ID: {creator_id}",
        f"Username: {username}",
        f"Profile: {profile}",
    ]

    if event.category_name:
        lines.append(f"Category: {_esc(event.category_name)}")

    return "\n".join(lines)


def _esc(text: str) -> str:
    """Escape HTML special characters for Telegram HTML parse mode."""
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
    )
