"""
core/config.py — Centralised environment config with validation.
All secrets are loaded from environment variables / .env file.
"""

from __future__ import annotations

from functools import lru_cache
from typing import List

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Required ──────────────────────────────────────────────────────────────
    discord_token: str
    telegram_token: str
    telegram_chat_id: str

    # ── Optional ──────────────────────────────────────────────────────────────
    log_level: str = "INFO"
    port: int = 8000

    # Comma-separated list of keywords that flag a channel as a ticket
    ticket_keywords: str = "ticket"

    # Comma-separated guild IDs to monitor; empty = all guilds
    allowed_guild_ids: str = ""

    # ── Computed properties ───────────────────────────────────────────────────
    @property
    def ticket_keyword_list(self) -> List[str]:
        return [k.strip().lower() for k in self.ticket_keywords.split(",") if k.strip()]

    @property
    def allowed_guild_id_list(self) -> List[int]:
        if not self.allowed_guild_ids.strip():
            return []
        return [int(g.strip()) for g in self.allowed_guild_ids.split(",") if g.strip()]

    # ── Validators ────────────────────────────────────────────────────────────
    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = v.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {allowed}, got '{v}'")
        return upper

    @model_validator(mode="after")
    def validate_required_secrets(self) -> "Settings":
        placeholders = {"your_discord_bot_token_here", "your_telegram_bot_token_here", "your_telegram_chat_id_here"}
        for field in ("discord_token", "telegram_token", "telegram_chat_id"):
            val = getattr(self, field)
            if not val or val in placeholders:
                raise ValueError(
                    f"Environment variable '{field.upper()}' is missing or still set to its placeholder value."
                )
        return self


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached Settings instance (singleton)."""
    return Settings()
