"""
core/telegram.py — Async Telegram Bot API client.

Uses httpx for async HTTP with retry logic and structured error handling.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional

import httpx

from core.logger import get_logger

log = get_logger(__name__)

_BASE_URL = "https://api.telegram.org/bot{token}/{method}"

# Retry config
_MAX_RETRIES = 3
_RETRY_BACKOFF = 2.0  # seconds; doubles each attempt


class TelegramError(Exception):
    """Raised when the Telegram API returns an error response."""

    def __init__(self, description: str, error_code: Optional[int] = None):
        self.description = description
        self.error_code = error_code
        super().__init__(f"Telegram API error {error_code}: {description}")


class TelegramClient:
    """
    Async Telegram Bot API client.

    Usage:
        async with TelegramClient(token, chat_id) as client:
            await client.send_message("Hello!")
    """

    def __init__(self, token: str, default_chat_id: str, timeout: float = 10.0):
        self._token = token
        self._default_chat_id = default_chat_id
        self._timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    # ── Context manager ───────────────────────────────────────────────────────

    async def __aenter__(self) -> "TelegramClient":
        self._client = httpx.AsyncClient(timeout=self._timeout)
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._client:
            await self._client.aclose()

    # ── Public API ────────────────────────────────────────────────────────────

    async def send_message(
        self,
        text: str,
        chat_id: Optional[str] = None,
        parse_mode: str = "HTML",
        disable_web_page_preview: bool = True,
    ) -> Dict[str, Any]:
        """Send a text message to Telegram. Retries on transient errors."""
        payload = {
            "chat_id": chat_id or self._default_chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": disable_web_page_preview,
        }
        return await self._post("sendMessage", payload)

    async def test_connection(self) -> Dict[str, Any]:
        """Call getMe to verify the token is valid."""
        return await self._post("getMe", {})

    # ── Internal helpers ──────────────────────────────────────────────────────

    async def _post(self, method: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = _BASE_URL.format(token=self._token, method=method)
        last_exc: Optional[Exception] = None

        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                log.debug("Telegram request attempt %d/%d: %s", attempt, _MAX_RETRIES, method)
                response = await self._ensure_client().post(url, json=payload)
                data: Dict[str, Any] = response.json()

                if not data.get("ok"):
                    raise TelegramError(
                        description=data.get("description", "Unknown error"),
                        error_code=data.get("error_code"),
                    )

                log.debug("Telegram %s succeeded on attempt %d", method, attempt)
                return data["result"]

            except TelegramError:
                raise  # Don't retry API-level errors
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_exc = exc
                wait = _RETRY_BACKOFF * (2 ** (attempt - 1))
                log.warning(
                    "Telegram request %s failed (attempt %d/%d): %s — retrying in %.1fs",
                    method, attempt, _MAX_RETRIES, exc, wait,
                )
                if attempt < _MAX_RETRIES:
                    await asyncio.sleep(wait)

        raise RuntimeError(
            f"Telegram {method} failed after {_MAX_RETRIES} attempts"
        ) from last_exc

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            # Allow use without context manager (e.g. in tests)
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client
