# Discord → Telegram Bridge

A production-ready system that monitors Discord for new ticket channels and forwards them to a Telegram bot.

## Features
- Detects new Discord channels containing "ticket" in the name
- Extracts channel name, ID, user ID, guild name, and creation time
- Sends formatted alerts to Telegram
- Two modes: **Bot-only** (simple) and **FastAPI webhook** (scalable)
- Structured logging, error handling, and health checks

## Project Structure

```
discord-telegram-bridge/
├── bot/
│   ├── __init__.py
│   ├── discord_bot.py        # Discord bot client & event handlers
│   └── events.py             # Ticket detection logic
├── core/
│   ├── __init__.py
│   ├── config.py             # Environment config & validation
│   ├── telegram.py           # Telegram API client
│   ├── formatter.py          # Message formatting
│   └── logger.py             # Structured logging setup
├── api/
│   ├── __init__.py
│   ├── app.py                # FastAPI app (optional webhook mode)
│   └── routes.py             # API routes & health endpoint
├── tests/
│   ├── test_formatter.py
│   └── test_telegram.py
├── main.py                   # Bot-only entry point
├── main_api.py               # FastAPI + bot entry point
├── requirements.txt
├── .env.example
├── Dockerfile
├── render.yaml               # Render.com deployment config
└── README.md
```

## Quick Start

### 1. Clone & Install
```bash
git clone <your-repo>
cd discord-telegram-bridge
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your tokens
```

### 3. Run (Bot Mode)
```bash
python main.py
```

### 4. Run (FastAPI Mode)
```bash
python main_api.py
# or
uvicorn main_api:app --host 0.0.0.0 --port 8000
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | Discord bot token |
| `TELEGRAM_TOKEN` | ✅ | Telegram bot token from @BotFather |
| `TELEGRAM_CHAT_ID` | ✅ | Target Telegram chat/channel ID |
| `LOG_LEVEL` | ❌ | Logging level (default: INFO) |
| `PORT` | ❌ | API server port (default: 8000) |
| `TICKET_KEYWORDS` | ❌ | Comma-separated keywords (default: ticket) |

## Getting Tokens

### Discord Bot Token
1. Go to https://discord.com/developers/applications
2. Create New Application → Bot → Reset Token
3. Enable **Server Members Intent** and **Message Content Intent** under Privileged Gateway Intents
4. Invite bot with `channels` and `guilds` permissions

### Telegram Bot Token
1. Message [@BotFather](https://t.me/botfather) on Telegram
2. Send `/newbot` and follow prompts
3. Copy the token provided

### Telegram Chat ID
- For a channel: forward a message to [@username_to_id_bot](https://t.me/username_to_id_bot)
- For a group: add [@RawDataBot](https://t.me/rawdatabot) and check the `id` field

## Deployment

### VPS (Ubuntu/Debian)
```bash
# Install dependencies
sudo apt update && sudo apt install python3-pip python3-venv -y

# Setup
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run with systemd (see systemd.service example below)
sudo systemctl enable discord-bridge
sudo systemctl start discord-bridge
```

### Render.com
Push to GitHub, then connect repo at render.com — `render.yaml` is pre-configured.

### Docker
```bash
docker build -t discord-telegram-bridge .
docker run -d --env-file .env discord-telegram-bridge
```
