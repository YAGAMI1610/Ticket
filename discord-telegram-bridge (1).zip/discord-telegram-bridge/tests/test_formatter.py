"""tests/test_formatter.py — Unit tests for message formatting."""

from __future__ import annotations

import pytest
from datetime import datetime, timezone

from core.formatter import TicketEvent, format_ticket_message, _esc


# ── TicketEvent tests ─────────────────────────────────────────────────────────

def test_ticket_event_channel_url():
    event = TicketEvent(
        channel_name="ticket-123",
        channel_id=111,
        guild_name="Test Server",
        guild_id=999,
    )
    assert event.channel_url == "https://discord.com/channels/999/111"


def test_ticket_event_defaults():
    event = TicketEvent(
        channel_name="ticket-abc",
        channel_id=1,
        guild_name="Guild",
        guild_id=2,
    )
    assert event.creator_id is None
    assert event.creator_name is None
    assert event.category_name is None
    assert event.detected_at.tzinfo == timezone.utc


# ── Formatter tests ───────────────────────────────────────────────────────────

def make_event(**kwargs) -> TicketEvent:
    defaults = dict(
        channel_name="ticket-general",
        channel_id=123456,
        guild_name="My Server",
        guild_id=654321,
    )
    defaults.update(kwargs)
    return TicketEvent(**defaults)


def test_format_contains_channel_name():
    msg = format_ticket_message(make_event())
    assert "ticket-general" in msg


def test_format_contains_guild_name():
    msg = format_ticket_message(make_event())
    assert "My Server" in msg


def test_format_contains_channel_id():
    msg = format_ticket_message(make_event())
    assert "123456" in msg


def test_format_with_creator():
    event = make_event(creator_id=999, creator_name="alice#0001")
    msg = format_ticket_message(event)
    assert "alice#0001" in msg
    assert "999" in msg


def test_format_without_creator_shows_unknown():
    msg = format_ticket_message(make_event())
    assert "Unknown" in msg


def test_format_with_category():
    event = make_event(category_name="Support Tickets")
    msg = format_ticket_message(event)
    assert "Support Tickets" in msg


def test_format_contains_jump_link():
    event = make_event(channel_id=111, guild_id=222)
    msg = format_ticket_message(event)
    assert "https://discord.com/channels/222/111" in msg


# ── HTML escaping tests ───────────────────────────────────────────────────────

def test_esc_ampersand():
    assert _esc("Tom & Jerry") == "Tom &amp; Jerry"


def test_esc_lt_gt():
    assert _esc("<script>") == "&lt;script&gt;"


def test_esc_quotes():
    assert _esc('"quoted"') == "&quot;quoted&quot;"


def test_esc_no_change_plain():
    assert _esc("Hello World") == "Hello World"
