"""tests/test_telegram.py — Tests for TelegramClient with mocked HTTP."""

from __future__ import annotations

import pytest
import respx
import httpx

from core.telegram import TelegramClient, TelegramError


FAKE_TOKEN = "123:ABC"
FAKE_CHAT_ID = "-100123456"
BASE = f"https://api.telegram.org/bot{FAKE_TOKEN}"


@pytest.fixture
def client():
    return TelegramClient(token=FAKE_TOKEN, default_chat_id=FAKE_CHAT_ID)


# ── send_message ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_send_message_success(client):
    respx.post(f"{BASE}/sendMessage").mock(
        return_value=httpx.Response(200, json={"ok": True, "result": {"message_id": 42}})
    )
    result = await client.send_message("Hello Telegram!")
    assert result["message_id"] == 42


@pytest.mark.asyncio
@respx.mock
async def test_send_message_api_error_raises(client):
    respx.post(f"{BASE}/sendMessage").mock(
        return_value=httpx.Response(
            200,
            json={"ok": False, "error_code": 400, "description": "Bad Request: chat not found"},
        )
    )
    with pytest.raises(TelegramError) as exc_info:
        await client.send_message("oops")
    assert exc_info.value.error_code == 400
    assert "chat not found" in exc_info.value.description


# ── test_connection ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_connection_returns_bot_info(client):
    respx.post(f"{BASE}/getMe").mock(
        return_value=httpx.Response(
            200,
            json={"ok": True, "result": {"id": 1, "username": "mybot", "is_bot": True}},
        )
    )
    result = await client.test_connection()
    assert result["username"] == "mybot"


# ── Context manager ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_context_manager_lifecycle():
    respx.post(f"{BASE}/sendMessage").mock(
        return_value=httpx.Response(200, json={"ok": True, "result": {"message_id": 1}})
    )
    async with TelegramClient(FAKE_TOKEN, FAKE_CHAT_ID) as tg:
        result = await tg.send_message("test")
    assert result["message_id"] == 1
