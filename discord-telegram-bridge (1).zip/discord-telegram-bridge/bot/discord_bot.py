"""
bot/discord_bot.py — Discord bot client with ticket detection.

Uses discord.py 2.x with proper intents and audit log enrichment.
"""

from __future__ import annotations

import asyncio
from typing import Optional

import discord
from discord.ext import tasks

from bot.events import build_ticket_event, is_ticket_channel
from core.config import Settings
from core.formatter import format_ticket_message
from core.logger import get_logger
from core.telegram import TelegramClient, TelegramError

log = get_logger(__name__)


class TicketBridgeBot(discord.Client):
    """
    Discord client that listens for new ticket channels and forwards
    a notification to Telegram.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

        intents = discord.Intents.default()
        intents.guilds = True          # Required for guild/channel events
        intents.guild_messages = True  # Optional: for message-based triggers

        super().__init__(intents=intents)

        self._telegram: Optional[TelegramClient] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def setup_hook(self) -> None:
        """Called once after login, before the main event loop."""
        self._telegram = TelegramClient(
            token=self.settings.telegram_token,
            default_chat_id=self.settings.telegram_chat_id,
        )
        # Open the HTTP client session early
        await self._telegram.__aenter__()
        log.info("Telegram client initialised")

        # Verify Telegram credentials at startup
        try:
            bot_info = await self._telegram.test_connection()
            log.info("Telegram bot verified: @%s", bot_info.get("username", "unknown"))
        except Exception as exc:
            log.error("Telegram connection test failed: %s", exc)

    async def close(self) -> None:
        """Graceful shutdown: close Telegram client then Discord connection."""
        log.info("Shutting down — closing connections…")
        if self._telegram:
            await self._telegram.__aexit__(None, None, None)
        await super().close()

    # ── Discord events ────────────────────────────────────────────────────────

    async def on_ready(self) -> None:
        guild_count = len(self.guilds)
        log.info(
            "Bot ready | logged in as %s (ID: %d) | monitoring %d guild(s)",
            self.user, self.user.id, guild_count,
        )
        for guild in self.guilds:
            log.info("  • %s (ID: %d)", guild.name, guild.id)

    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        """Fired whenever any channel is created in a monitored guild."""
        log.debug("Channel created: %s (type: %s)", channel.name, type(channel).__name__)

        if not is_ticket_channel(
            channel,
            keywords=self.settings.ticket_keyword_list,
            allowed_guild_ids=self.settings.allowed_guild_id_list or None,
        ):
            return

        log.info("Ticket channel detected: #%s in %s", channel.name, channel.guild.name)

        # Try to get creator info from audit log (requires VIEW_AUDIT_LOG permission)
        entry = await self._fetch_audit_log_entry(
            channel.guild, discord.AuditLogAction.channel_create
        )

        event = build_ticket_event(channel, entry)
        message = format_ticket_message(event)

        await self._send_to_telegram(message)

    async def on_error(self, event_method: str, *args, **kwargs) -> None:
        log.exception("Unhandled error in event '%s'", event_method)

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def _fetch_audit_log_entry(
        self,
        guild: discord.Guild,
        action: discord.AuditLogAction,
    ) -> Optional[discord.AuditLogEntry]:
        """
        Attempt to retrieve the most recent audit log entry for a given action.
        Returns None if the bot lacks VIEW_AUDIT_LOG permission.
        """
        try:
            async for entry in guild.audit_logs(limit=1, action=action):
                return entry
        except discord.Forbidden:
            log.warning(
                "Bot lacks VIEW_AUDIT_LOG permission in guild '%s' — creator info unavailable",
                guild.name,
            )
        except discord.HTTPException as exc:
            log.warning("Failed to fetch audit log for guild '%s': %s", guild.name, exc)
        return None

    async def _send_to_telegram(self, message: str) -> None:
        """Send a formatted message to Telegram with error handling."""
        if not self._telegram:
            log.error("Telegram client not initialised — cannot send message")
            return
        try:
            await self._telegram.send_message(message)
            log.info("Telegram notification sent successfully")
        except TelegramError as exc:
            log.error("Telegram API error: %s", exc)
        except Exception as exc:
            log.exception("Unexpected error sending Telegram message: %s", exc)


def create_bot(settings: Settings) -> TicketBridgeBot:
    """Factory function — creates and returns a configured bot instance."""
    return TicketBridgeBot(settings=settings)
