"""bot — Discord client and event handlers."""
