"""
bot/events.py — Ticket channel detection logic.

Separated from the bot client so it can be unit-tested independently.
"""

from __future__ import annotations

from typing import List, Optional

import discord

from core.formatter import TicketEvent
from core.logger import get_logger

log = get_logger(__name__)


def is_ticket_channel(
    channel: discord.abc.GuildChannel,
    keywords: List[str],
    allowed_guild_ids: Optional[List[int]] = None,
) -> bool:
    """
    Return True if the channel should be treated as a ticket.

    Rules:
    - Channel must be a TextChannel (not voice, category, etc.)
    - Channel name must contain at least one keyword (case-insensitive)
    - If allowed_guild_ids is non-empty, guild must be in the list
    """
    if not isinstance(channel, discord.TextChannel):
        return False

    if allowed_guild_ids and channel.guild.id not in allowed_guild_ids:
        log.debug(
            "Skipping channel %s — guild %d not in allowed list",
            channel.name, channel.guild.id,
        )
        return False

    channel_lower = channel.name.lower()
    matched = any(kw in channel_lower for kw in keywords)

    if matched:
        log.debug("Ticket keyword matched in channel '%s'", channel.name)

    return matched


def build_ticket_event(
    channel: discord.TextChannel,
    entry: Optional[discord.AuditLogEntry] = None,
) -> TicketEvent:
    """
    Build a TicketEvent from a Discord TextChannel.

    Optionally enriches with audit log data (creator info).
    """
    creator_id: Optional[int] = None
    creator_name: Optional[str] = None

    if entry and entry.user:
        creator_id = entry.user.id
        creator_name = str(entry.user)

    return TicketEvent(
        channel_name=channel.name,
        channel_id=channel.id,
        guild_name=channel.guild.name,
        guild_id=channel.guild.id,
        creator_id=creator_id,
        creator_name=creator_name,
        category_name=channel.category.name if channel.category else None,
    )
