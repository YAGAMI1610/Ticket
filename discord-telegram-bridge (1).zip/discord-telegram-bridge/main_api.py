"""
main_api.py — FastAPI + Discord bot entry point.

Run with:
    python main_api.py
    # or
    uvicorn main_api:app --host 0.0.0.0 --port 8000

This mode exposes:
  - GET  /health    — health check (use for Render/Kubernetes probes)
  - GET  /status    — bot status + connected guilds
  - POST /webhook   — manual notification trigger
  - GET  /docs      — Swagger UI
"""

from __future__ import annotations

import os
import sys

import uvicorn

from api.app import create_app
from core.config import get_settings
from core.logger import setup_logging

# Initialise logging before anything else
_settings = get_settings()
setup_logging(_settings.log_level)

# Export `app` at module level so uvicorn can import it directly:
#   uvicorn main_api:app --reload
app = create_app()


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(
        "main_api:app",
        host="0.0.0.0",
        port=port,
        log_level=_settings.log_level.lower(),
        # Use reload=True only in development
        reload=os.getenv("ENV", "production").lower() == "development",
    )
